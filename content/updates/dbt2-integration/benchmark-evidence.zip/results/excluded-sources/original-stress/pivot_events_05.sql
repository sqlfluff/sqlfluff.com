{{ config(materialized='table') }}
{% set kinds = ['view', 'purchase', 'refund', 'signup'] %}
{% set dimensions = ['customer_id', 'event_date'] %}
{% set enabled = var('include_refunds', true) %}
{% set projected %}
    {{ dimensions | join(', ') }}
{% endset %}

with base as (
    select *
    from {{ ref('dim_events_05') }}
)

select
    {{ projected }},
    {{ dbt_utils.generate_surrogate_key(dimensions) }} as group_key,
    {% for kind in kinds %}
        {% if kind == 'refund' and not enabled %}
            0 as {{ kind }}_amount,
        {% elif kind == 'purchase' %}
            {{ conditional_sum('amount', 'event_type', kind) }} as {{ kind }}_amount,
        {% else %}
            {{ conditional_sum('amount', 'event_type', kind) }} as {{ kind }}_amount,
        {% endif %}
    {% endfor %}
    {% for modulus in range(2, 32) %}
        {% for parity in range(2) %}
            sum(case when event_id % {{ modulus }} = {{ parity }} then amount else 0 end)
                as bucket_{{ modulus }}_{{ parity }},
        {% endfor %}
    {% endfor %}
    sum(amount) as total_amount
from base
{{ dbt_utils.group_by(n=2) }}
