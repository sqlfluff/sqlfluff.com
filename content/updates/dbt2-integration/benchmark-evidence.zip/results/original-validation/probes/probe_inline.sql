select
    customer_id,
    {% for modulus in range(2, 32) %}sum(case when event_id % {{ modulus }} = 0 then amount else 0 end) as bucket_{{ modulus }},
    {% endfor %}sum(amount) as total_amount
from {{ ref('dim_events_00') }}
group by customer_id
