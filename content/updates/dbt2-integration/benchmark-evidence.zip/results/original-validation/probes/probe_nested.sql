select
    customer_id,
    {% for modulus in range(2, 32) %}
        {% for parity in range(2) %}
            sum(case when event_id % {{ modulus }} = {{ parity }} then amount else 0 end) as bucket_{{ modulus }}_{{ parity }},
        {% endfor %}
    {% endfor %}
    sum(amount) as total_amount
from {{ ref('dim_events_00') }}
group by customer_id
