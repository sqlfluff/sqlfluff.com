





with base as (
    select *
    from "benchmark"."main"."dim_events_09"
)

select
    
    customer_id, event_date
,
    md5(cast(coalesce(cast(customer_id as TEXT), '_dbt_utils_surrogate_key_null_') || '-' || coalesce(cast(event_date as TEXT), '_dbt_utils_surrogate_key_null_') as TEXT)) as group_key,
    
        
            sum(case when event_type = 'view' then amount else 0 end) as view_amount,
        
    
        
            sum(case when event_type = 'purchase' then amount else 0 end) as purchase_amount,
        
    
        
            sum(case when event_type = 'refund' then amount else 0 end) as refund_amount,
        
    
        
            sum(case when event_type = 'signup' then amount else 0 end) as signup_amount,
        
    
    
        
            sum(case when event_id % 2 = 0 then amount else 0 end)
                as bucket_2_0,
        
            sum(case when event_id % 2 = 1 then amount else 0 end)
                as bucket_2_1,
        
    
        
            sum(case when event_id % 3 = 0 then amount else 0 end)
                as bucket_3_0,
        
            sum(case when event_id % 3 = 1 then amount else 0 end)
                as bucket_3_1,
        
    
        
            sum(case when event_id % 4 = 0 then amount else 0 end)
                as bucket_4_0,
        
            sum(case when event_id % 4 = 1 then amount else 0 end)
                as bucket_4_1,
        
    
        
            sum(case when event_id % 5 = 0 then amount else 0 end)
                as bucket_5_0,
        
            sum(case when event_id % 5 = 1 then amount else 0 end)
                as bucket_5_1,
        
    
        
            sum(case when event_id % 6 = 0 then amount else 0 end)
                as bucket_6_0,
        
            sum(case when event_id % 6 = 1 then amount else 0 end)
                as bucket_6_1,
        
    
        
            sum(case when event_id % 7 = 0 then amount else 0 end)
                as bucket_7_0,
        
            sum(case when event_id % 7 = 1 then amount else 0 end)
                as bucket_7_1,
        
    
        
            sum(case when event_id % 8 = 0 then amount else 0 end)
                as bucket_8_0,
        
            sum(case when event_id % 8 = 1 then amount else 0 end)
                as bucket_8_1,
        
    
        
            sum(case when event_id % 9 = 0 then amount else 0 end)
                as bucket_9_0,
        
            sum(case when event_id % 9 = 1 then amount else 0 end)
                as bucket_9_1,
        
    
        
            sum(case when event_id % 10 = 0 then amount else 0 end)
                as bucket_10_0,
        
            sum(case when event_id % 10 = 1 then amount else 0 end)
                as bucket_10_1,
        
    
        
            sum(case when event_id % 11 = 0 then amount else 0 end)
                as bucket_11_0,
        
            sum(case when event_id % 11 = 1 then amount else 0 end)
                as bucket_11_1,
        
    
        
            sum(case when event_id % 12 = 0 then amount else 0 end)
                as bucket_12_0,
        
            sum(case when event_id % 12 = 1 then amount else 0 end)
                as bucket_12_1,
        
    
        
            sum(case when event_id % 13 = 0 then amount else 0 end)
                as bucket_13_0,
        
            sum(case when event_id % 13 = 1 then amount else 0 end)
                as bucket_13_1,
        
    
        
            sum(case when event_id % 14 = 0 then amount else 0 end)
                as bucket_14_0,
        
            sum(case when event_id % 14 = 1 then amount else 0 end)
                as bucket_14_1,
        
    
        
            sum(case when event_id % 15 = 0 then amount else 0 end)
                as bucket_15_0,
        
            sum(case when event_id % 15 = 1 then amount else 0 end)
                as bucket_15_1,
        
    
        
            sum(case when event_id % 16 = 0 then amount else 0 end)
                as bucket_16_0,
        
            sum(case when event_id % 16 = 1 then amount else 0 end)
                as bucket_16_1,
        
    
        
            sum(case when event_id % 17 = 0 then amount else 0 end)
                as bucket_17_0,
        
            sum(case when event_id % 17 = 1 then amount else 0 end)
                as bucket_17_1,
        
    
        
            sum(case when event_id % 18 = 0 then amount else 0 end)
                as bucket_18_0,
        
            sum(case when event_id % 18 = 1 then amount else 0 end)
                as bucket_18_1,
        
    
        
            sum(case when event_id % 19 = 0 then amount else 0 end)
                as bucket_19_0,
        
            sum(case when event_id % 19 = 1 then amount else 0 end)
                as bucket_19_1,
        
    
        
            sum(case when event_id % 20 = 0 then amount else 0 end)
                as bucket_20_0,
        
            sum(case when event_id % 20 = 1 then amount else 0 end)
                as bucket_20_1,
        
    
        
            sum(case when event_id % 21 = 0 then amount else 0 end)
                as bucket_21_0,
        
            sum(case when event_id % 21 = 1 then amount else 0 end)
                as bucket_21_1,
        
    
        
            sum(case when event_id % 22 = 0 then amount else 0 end)
                as bucket_22_0,
        
            sum(case when event_id % 22 = 1 then amount else 0 end)
                as bucket_22_1,
        
    
        
            sum(case when event_id % 23 = 0 then amount else 0 end)
                as bucket_23_0,
        
            sum(case when event_id % 23 = 1 then amount else 0 end)
                as bucket_23_1,
        
    
        
            sum(case when event_id % 24 = 0 then amount else 0 end)
                as bucket_24_0,
        
            sum(case when event_id % 24 = 1 then amount else 0 end)
                as bucket_24_1,
        
    
        
            sum(case when event_id % 25 = 0 then amount else 0 end)
                as bucket_25_0,
        
            sum(case when event_id % 25 = 1 then amount else 0 end)
                as bucket_25_1,
        
    
        
            sum(case when event_id % 26 = 0 then amount else 0 end)
                as bucket_26_0,
        
            sum(case when event_id % 26 = 1 then amount else 0 end)
                as bucket_26_1,
        
    
        
            sum(case when event_id % 27 = 0 then amount else 0 end)
                as bucket_27_0,
        
            sum(case when event_id % 27 = 1 then amount else 0 end)
                as bucket_27_1,
        
    
        
            sum(case when event_id % 28 = 0 then amount else 0 end)
                as bucket_28_0,
        
            sum(case when event_id % 28 = 1 then amount else 0 end)
                as bucket_28_1,
        
    
        
            sum(case when event_id % 29 = 0 then amount else 0 end)
                as bucket_29_0,
        
            sum(case when event_id % 29 = 1 then amount else 0 end)
                as bucket_29_1,
        
    
        
            sum(case when event_id % 30 = 0 then amount else 0 end)
                as bucket_30_0,
        
            sum(case when event_id % 30 = 1 then amount else 0 end)
                as bucket_30_1,
        
    
        
            sum(case when event_id % 31 = 0 then amount else 0 end)
                as bucket_31_0,
        
            sum(case when event_id % 31 = 1 then amount else 0 end)
                as bucket_31_1,
        
    
    sum(amount) as total_amount
from base
group by 1,2
