with base as (
    select *
    from "benchmark"."main"."dim_events_00"
),

enriched as (
    select
        event_id,
        customer_id,
        event_type,
        amount,
        event_date,
        row_number() over (
            partition by customer_id
            order by event_date, event_id
        ) as event_rank,
        sum(amount) over (
            partition by customer_id
            order by event_date, event_id
            rows between unbounded preceding and current row
        ) as running_amount
    from base
)

select
    customer_id,
    event_type,
    count(*) as event_count,
    max(event_rank) as last_rank,
    max(running_amount) as running_amount,
    sum(case when event_id % 2 = 0 then amount else 0 end) as amount_00,
    sum(case when event_id % 3 = 0 then amount else 0 end) as amount_01,
    sum(case when event_id % 4 = 0 then amount else 0 end) as amount_02,
    sum(case when event_id % 5 = 0 then amount else 0 end) as amount_03,
    sum(case when event_id % 6 = 0 then amount else 0 end) as amount_04,
    sum(case when event_id % 7 = 0 then amount else 0 end) as amount_05,
    sum(case when event_id % 8 = 0 then amount else 0 end) as amount_06,
    sum(case when event_id % 9 = 0 then amount else 0 end) as amount_07,
    sum(case when event_id % 10 = 0 then amount else 0 end) as amount_08,
    sum(case when event_id % 11 = 0 then amount else 0 end) as amount_09,
    sum(case when event_id % 12 = 0 then amount else 0 end) as amount_10,
    sum(case when event_id % 13 = 0 then amount else 0 end) as amount_11,
    sum(case when event_id % 14 = 0 then amount else 0 end) as amount_12,
    sum(case when event_id % 15 = 0 then amount else 0 end) as amount_13,
    sum(case when event_id % 16 = 0 then amount else 0 end) as amount_14,
    sum(case when event_id % 17 = 0 then amount else 0 end) as amount_15,
    sum(case when event_id % 18 = 0 then amount else 0 end) as amount_16,
    sum(case when event_id % 19 = 0 then amount else 0 end) as amount_17,
    sum(case when event_id % 20 = 0 then amount else 0 end) as amount_18,
    sum(case when event_id % 21 = 0 then amount else 0 end) as amount_19,
    sum(case when event_id % 22 = 0 then amount else 0 end) as amount_20,
    sum(case when event_id % 23 = 0 then amount else 0 end) as amount_21,
    sum(case when event_id % 24 = 0 then amount else 0 end) as amount_22,
    sum(case when event_id % 25 = 0 then amount else 0 end) as amount_23,
    sum(case when event_id % 26 = 0 then amount else 0 end) as amount_24
from enriched
group by customer_id, event_type