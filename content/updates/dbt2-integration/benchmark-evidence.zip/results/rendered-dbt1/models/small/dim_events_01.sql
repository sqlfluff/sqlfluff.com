

select
    event_id,
    customer_id,
    event_type,
    round(cast(amount as decimal(18, 4)), 2) as amount,
    event_date,
    md5(cast(coalesce(cast(event_id as TEXT), '_dbt_utils_surrogate_key_null_') || '-' || coalesce(cast(customer_id as TEXT), '_dbt_utils_surrogate_key_null_') as TEXT)) as event_key
from "benchmark"."main"."stg_events_01"
