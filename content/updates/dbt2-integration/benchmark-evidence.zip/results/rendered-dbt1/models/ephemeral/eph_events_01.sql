

select
    event_id,
    customer_id,
    event_type,
    amount,
    event_date
from "benchmark"."main"."stg_events_01"
where amount > 0
