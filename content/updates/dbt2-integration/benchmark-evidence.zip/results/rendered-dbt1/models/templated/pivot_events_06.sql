


select
    customer_id,
    event_date,
    md5(cast(coalesce(cast(customer_id as TEXT), '_dbt_utils_surrogate_key_null_') || '-' || coalesce(cast(event_date as TEXT), '_dbt_utils_surrogate_key_null_') as TEXT)) as group_key,
    
        sum(case when event_id % 2 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_2,
    
        sum(case when event_id % 3 = 1 then amount else 0 end)
     as bucket_3,
    
        sum(case when event_id % 4 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_4,
    
        sum(case when event_id % 5 = 1 then amount else 0 end)
     as bucket_5,
    
        sum(case when event_id % 6 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_6,
    
        sum(case when event_id % 7 = 1 then amount else 0 end)
     as bucket_7,
    
        sum(case when event_id % 8 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_8,
    
        sum(case when event_id % 9 = 1 then amount else 0 end)
     as bucket_9,
    
        sum(case when event_id % 10 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_10,
    
        sum(case when event_id % 11 = 1 then amount else 0 end)
     as bucket_11,
    
        sum(case when event_id % 12 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_12,
    
        sum(case when event_id % 13 = 1 then amount else 0 end)
     as bucket_13,
    
        sum(case when event_id % 14 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_14,
    
        sum(case when event_id % 15 = 1 then amount else 0 end)
     as bucket_15,
    
        sum(case when event_id % 16 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_16,
    
        sum(case when event_id % 17 = 1 then amount else 0 end)
     as bucket_17,
    
        sum(case when event_id % 18 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_18,
    
        sum(case when event_id % 19 = 1 then amount else 0 end)
     as bucket_19,
    
        sum(case when event_id % 20 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_20,
    
        sum(case when event_id % 21 = 1 then amount else 0 end)
     as bucket_21,
    
        sum(case when event_id % 22 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_22,
    
        sum(case when event_id % 23 = 1 then amount else 0 end)
     as bucket_23,
    
        sum(case when event_id % 24 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_24,
    
        sum(case when event_id % 25 = 1 then amount else 0 end)
     as bucket_25,
    
        sum(case when event_id % 26 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_26,
    
        sum(case when event_id % 27 = 1 then amount else 0 end)
     as bucket_27,
    
        sum(case when event_id % 28 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_28,
    
        sum(case when event_id % 29 = 1 then amount else 0 end)
     as bucket_29,
    
        sum(case when event_id % 30 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_30,
    
        sum(case when event_id % 31 = 1 then amount else 0 end)
     as bucket_31,
    
        sum(case when event_id % 32 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_32,
    
        sum(case when event_id % 33 = 1 then amount else 0 end)
     as bucket_33,
    
        sum(case when event_id % 34 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_34,
    
        sum(case when event_id % 35 = 1 then amount else 0 end)
     as bucket_35,
    
        sum(case when event_id % 36 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_36,
    
        sum(case when event_id % 37 = 1 then amount else 0 end)
     as bucket_37,
    
        sum(case when event_id % 38 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_38,
    
        sum(case when event_id % 39 = 1 then amount else 0 end)
     as bucket_39,
    
        sum(case when event_id % 40 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_40,
    
        sum(case when event_id % 41 = 1 then amount else 0 end)
     as bucket_41,
    
        sum(case when event_id % 42 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_42,
    
        sum(case when event_id % 43 = 1 then amount else 0 end)
     as bucket_43,
    
        sum(case when event_id % 44 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_44,
    
        sum(case when event_id % 45 = 1 then amount else 0 end)
     as bucket_45,
    
        sum(case when event_id % 46 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_46,
    
        sum(case when event_id % 47 = 1 then amount else 0 end)
     as bucket_47,
    
        sum(case when event_id % 48 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_48,
    
        sum(case when event_id % 49 = 1 then amount else 0 end)
     as bucket_49,
    
        sum(case when event_id % 50 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_50,
    
        sum(case when event_id % 51 = 1 then amount else 0 end)
     as bucket_51,
    
        sum(case when event_id % 52 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_52,
    
        sum(case when event_id % 53 = 1 then amount else 0 end)
     as bucket_53,
    
        sum(case when event_id % 54 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_54,
    
        sum(case when event_id % 55 = 1 then amount else 0 end)
     as bucket_55,
    
        sum(case when event_id % 56 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_56,
    
        sum(case when event_id % 57 = 1 then amount else 0 end)
     as bucket_57,
    
        sum(case when event_id % 58 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_58,
    
        sum(case when event_id % 59 = 1 then amount else 0 end)
     as bucket_59,
    
        sum(case when event_id % 60 = 0 then round(cast(amount as decimal(18, 4)), 2) else 0 end)
     as bucket_60,
    
        sum(case when event_id % 61 = 1 then amount else 0 end)
     as bucket_61,
    sum(amount) as total_amount
from "benchmark"."main"."dim_events_06"
group by 1,2
