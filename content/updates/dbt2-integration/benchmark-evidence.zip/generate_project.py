"""Generate an identical, deterministic DuckDB workload for both templaters."""

from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def generate() -> None:
    models: dict[str, tuple[str, str]] = {}
    for i in range(10):
        sql = """select
    event_id,
    customer_id,
    event_type,
    amount,
    event_date
from {{ source('raw', 'events') }}
where event_id % 10 = """ + str(i) + "\n"
        models[f"staging/stg_events_{i:02}"] = ("small_staging", sql)
    for i in range(20):
        sql = """{{ config(materialized='view') }}

select
    event_id,
    customer_id,
    event_type,
    {{ money('amount') }} as amount,
    event_date,
    {{ dbt_utils.generate_surrogate_key(['event_id', 'customer_id']) }} as event_key
from {{ ref('stg_events_""" + f"{i % 10:02}" + "') }}\n"
        models[f"small/dim_events_{i:02}"] = ("small_macro_utils", sql)
    for i in range(5):
        sql = """{{ config(materialized='ephemeral') }}

select
    event_id,
    customer_id,
    event_type,
    amount,
    event_date
from {{ ref('stg_events_""" + f"{i:02}" + "') }}\nwhere amount > 0\n"
        models[f"ephemeral/eph_events_{i:02}"] = ("ephemeral", sql)
    for i in range(30):
        columns = [
            f"    sum(case when event_id % {j + 2} = 0 then amount else 0 end) as amount_{j:02}"
            for j in range(25)
        ]
        sql = """with base as (
    select *
    from {{ ref('dim_events_""" + f"{i % 20:02}" + """') }}
),

enriched as (
    select
        event_id,
        customer_id,
        event_type,
        amount,
        event_date,
        row_number() over (
            partition by customer_id
            order by event_date, event_id
        ) as event_rank,
        sum(amount) over (
            partition by customer_id
            order by event_date, event_id
            rows between unbounded preceding and current row
        ) as running_amount
    from base
)

select
    customer_id,
    event_type,
    count(*) as event_count,
    max(event_rank) as last_rank,
    max(running_amount) as running_amount,
""" + ",\n".join(columns) + "\nfrom enriched\ngroup by customer_id, event_type\n"
        models[f"medium/customer_metrics_{i:02}"] = ("medium_windows_aggregates", sql)
    for i in range(20):
        source = f"eph_events_{i % 5:02}" if i < 5 else f"stg_events_{i % 10:02}"
        ctes = ["base as (\n    select *\n    from {{ ref('" + source + "') }}\n)"]
        for j in range(8):
            columns = [
                f"        case when event_id % {k + j + 2} = 0 then amount else 0 end as metric_{k:02}"
                for k in range(22)
            ]
            ctes.append(
                f"features_{j} as (\n    select\n        event_id,\n        customer_id,\n"
                "        event_type,\n        amount,\n        event_date,\n"
                + ",\n".join(columns) + "\n    from base\n)"
            )
        outputs = ["    f0.event_id", "    f0.customer_id", "    f0.event_type", "    f0.amount", "    f0.event_date"]
        outputs.extend(f"    f{j}.metric_{k:02} as metric_{j}_{k:02}" for j in range(8) for k in range(6))
        sql = "with " + ",\n\n".join(ctes) + "\n\nselect\n" + ",\n".join(outputs) + "\nfrom features_0 as f0\n"
        sql += "".join(f"left join features_{j} as f{j}\n    on f0.event_id = f{j}.event_id\n" for j in range(1, 8))
        models[f"large/wide_features_{i:02}"] = ("large_ctes_joins", sql)
    for i in range(10):
        sql = """{{ config(materialized='table') }}
{% set kinds = ['view', 'purchase', 'refund', 'signup'] %}
{% set dimensions = ['customer_id', 'event_date'] %}
{% set enabled = var('include_refunds', true) %}
{% set projected %}
    {{ dimensions | join(', ') }}
{% endset %}

with base as (
    select *
    from {{ ref('dim_events_""" + f"{i:02}" + """') }}
)

select
    {{ projected }},
    {{ dbt_utils.generate_surrogate_key(dimensions) }} as group_key,
    {% for kind in kinds %}
        {% if kind == 'refund' and not enabled %}
            0 as {{ kind }}_amount,
        {% elif kind == 'purchase' %}
            {{ conditional_sum('amount', 'event_type', kind) }} as {{ kind }}_amount,
        {% else %}
            {{ conditional_sum('amount', 'event_type', kind) }} as {{ kind }}_amount,
        {% endif %}
    {% endfor %}
    {% for modulus in range(2, 32) %}
        {% for parity in range(2) %}
            sum(case when event_id % {{ modulus }} = {{ parity }} then amount else 0 end)
                as bucket_{{ modulus }}_{{ parity }},
        {% endfor %}
    {% endfor %}
    sum(amount) as total_amount
from base
{{ dbt_utils.group_by(n=2) }}
"""
        # Preserve the initially proposed stress case, which exposes duplicate
        # and inconsistent LT02 diagnostics in the experimental consumer.
        write(ROOT / "results/excluded-sources/original-stress" / f"pivot_events_{i:02}.sql", sql)
        sql = """{{ config(materialized='table') }}
{% set moduli = range(2, 62) %}

select
    customer_id,
    event_date,
    {{ dbt_utils.generate_surrogate_key(['customer_id', 'event_date']) }} as group_key,
    {% for modulus in moduli %}{{ bucket(modulus) }} as bucket_{{ modulus }},
    {% endfor %}sum(amount) as total_amount
from {{ ref('dim_events_""" + f"{i:02}" + """') }}
{{ dbt_utils.group_by(n=2) }}
"""
        models[f"templated/pivot_events_{i:02}"] = ("inline_loop_nested_macros_branches_utils", sql)
    for i in range(5):
        sql = """{{ config(materialized='incremental', unique_key='event_id', incremental_strategy='delete+insert') }}

select
    event_id,
    customer_id,
    event_type,
    {{ money('amount') }} as amount,
    event_date,
    {{ dbt_utils.generate_surrogate_key(['event_id', 'customer_id']) }} as event_key
from {{ ref('stg_events_""" + f"{i:02}" + """') }}
{% if is_incremental() %}
    where event_date >= (select max(event_date) from {{ this }})
{% else %}
    where event_id >= 0
{% endif %}
"""
        models[f"incremental/fct_events_{i:02}"] = ("incremental_utils", sql)
    assert len(models) == 100
    inventory = []
    for runtime in ("dbt1", "dbt2"):
        project = ROOT / f"project-{runtime}"
        write(project / "dbt_project.yml", """name: templater_benchmark
version: '1.0.0'
config-version: 2
profile: templater_benchmark
model-paths: ['models']
seed-paths: ['seeds']
macro-paths: ['macros']
models:
  templater_benchmark:
    +materialized: view
flags:
  send_anonymous_usage_stats: false
""")
        write(project / "profiles.yml", """templater_benchmark:
  target: dev
  outputs:
    dev:
      type: duckdb
      path: benchmark.duckdb
      schema: main
      threads: 1
""")
        write(project / "packages.yml", "packages:\n  - package: dbt-labs/dbt_utils\n    version: 1.3.3\n")
        write(project / "models/sources.yml", "version: 2\nsources:\n  - name: raw\n    schema: main\n    tables:\n      - name: events\n")
        write(project / "macros/benchmark.sql", """{% macro money(expression, scale=2) -%}
    round(cast({{ expression }} as decimal(18, 4)), {{ scale }})
{%- endmacro %}

{% macro conditional_sum(value, column, kind) -%}
    {% set predicate = column ~ " = '" ~ kind ~ "'" %}
    {{ return('sum(case when ' ~ predicate ~ ' then ' ~ value ~ ' else 0 end)') }}
{%- endmacro %}

{% macro bucket(modulus) -%}
    {% if modulus % 2 == 0 %}
        sum(case when event_id % {{ modulus }} = 0 then {{ money('amount') }} else 0 end)
    {% else %}
        sum(case when event_id % {{ modulus }} = 1 then amount else 0 end)
    {% endif %}
{%- endmacro %}
""")
        for name, (category, sql) in models.items():
            write(project / "models" / f"{name}.sql", sql)
            if runtime == "dbt1":
                inventory.append({"path": f"models/{name}.sql", "category": category, "source_lines": len(sql.splitlines()), "source_bytes": len(sql.encode())})
        (project / "seeds").mkdir(exist_ok=True)
        with (project / "seeds/events.csv").open("w", newline="", encoding="utf-8") as stream:
            writer = csv.writer(stream)
            writer.writerow(["event_id", "customer_id", "event_type", "amount", "event_date"])
            for row in range(1000):
                writer.writerow([row, row % 100, ["view", "purchase", "refund", "signup"][row % 4], f"{(row * 137) % 10000 / 100:.2f}", f"2026-01-{row % 28 + 1:02}"])
        write(project / "lint.ini", f"""[sqlfluff]
templater = {runtime if runtime == 'dbt2' else 'dbt'}
dialect = duckdb
processes = 1
use_rust_parser = False
large_file_skip_byte_limit = 0
max_line_length = 120

[sqlfluff:templater:{runtime if runtime == 'dbt2' else 'dbt'}]
project_dir = {project.as_posix()}
profiles_dir = {project.as_posix()}
timeout = 600
""")
    write(ROOT / "results/model-inventory.json", json.dumps(inventory, indent=2))
    selections = {
        "one-small": ["models/small/dim_events_00.sql"],
        "one-large": ["models/large/wide_features_00.sql"],
        "one-templated": ["models/templated/pivot_events_00.sql"],
        "five-mixed": ["models/staging/stg_events_00.sql", "models/small/dim_events_00.sql", "models/medium/customer_metrics_00.sql", "models/large/wide_features_00.sql", "models/templated/pivot_events_00.sql"],
        "five-incremental": [f"models/incremental/fct_events_{i:02}.sql" for i in range(5)],
        "all": [entry["path"] for entry in inventory],
    }
    write(ROOT / "results/selections.json", json.dumps(selections, indent=2))
    print(f"Generated {len(models)} models per runtime, {sum(x['source_lines'] for x in inventory)} source lines")


if __name__ == "__main__":
    generate()
