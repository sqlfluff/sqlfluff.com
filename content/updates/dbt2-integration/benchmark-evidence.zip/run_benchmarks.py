"""Time real, fresh-process SQLFluff commands and reject incomplete runs."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import random
import shutil
import statistics
import subprocess
import time
from collections import Counter, defaultdict
from pathlib import Path

import psutil

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def environment(runtime: str) -> dict[str, str]:
    env = os.environ.copy()
    env.update({
        "DBT_SEND_ANONYMOUS_USAGE_STATS": "false",
        "DO_NOT_TRACK": "1",
        "PYTHONHASHSEED": "0",
        "PYTHONUTF8": "1",
        "NO_COLOR": "1",
        "TEMP": str(ROOT / "tmp"),
        "TMP": str(ROOT / "tmp"),
        "PATH": str(ROOT / f"env-{runtime}/Scripts") + os.pathsep + env["PATH"],
    })
    (ROOT / "tmp").mkdir(exist_ok=True)
    return env


def clear_artifacts(project: Path) -> None:
    for name in ("target", "logs"):
        target = (project / name).resolve()
        assert target.is_relative_to(project.resolve()) and target.name == name
        if target.exists():
            shutil.rmtree(target)


def execute(runtime: str, selection: str, mode: str, repeat: int) -> dict:
    project = ROOT / f"project-{runtime}"
    paths = json.loads((RESULTS / "selections.json").read_text())[selection]
    label = f"{mode}-{selection}-{runtime}-{repeat:02}"
    if mode == "cleared":
        clear_artifacts(project)
    timing = RESULTS / f"{label}-phases.csv"
    command = [str(ROOT / f"env-{runtime}/Scripts/python.exe"), "-m", "sqlfluff", "lint", "--ignore-local-config", "--config", "lint.ini", "--disable-progress-bar", "--format", "json", "--persist-timing", str(timing), *(["models"] if selection == "all" else paths)]
    stdout = ROOT / "logs" / f"{label}.json"
    stderr = ROOT / "logs" / f"{label}.stderr"
    peak_rss = 0
    peak_private = 0
    max_processes = 0
    started = time.perf_counter()
    with stdout.open("wb") as out, stderr.open("wb") as err:
        proc = subprocess.Popen(command, cwd=project, env=environment(runtime), stdout=out, stderr=err)
        parent = psutil.Process(proc.pid)
        while proc.poll() is None:
            rss = private = count = 0
            try:
                processes = [parent, *parent.children(recursive=True)]
            except psutil.Error:
                processes = []
            for child in processes:
                try:
                    memory = child.memory_info()
                    rss += memory.rss
                    private += getattr(memory, "private", 0)
                    count += 1
                except psutil.Error:
                    pass
            peak_rss = max(peak_rss, rss)
            peak_private = max(peak_private, private)
            max_processes = max(max_processes, count)
            if time.perf_counter() - started > 900:
                for child in reversed(processes):
                    try:
                        child.kill()
                    except psutil.Error:
                        pass
                raise RuntimeError(f"Timed out: {label}")
            try:
                proc.wait(timeout=0.025)
            except subprocess.TimeoutExpired:
                pass
        returncode = proc.wait()
    elapsed = time.perf_counter() - started
    try:
        files = json.loads(stdout.read_text(encoding="utf-8"))
    except Exception as error:
        raise RuntimeError(f"Invalid lint JSON: {label}, exit {returncode}; see {stdout}") from error
    actual = {Path(file["filepath"]).as_posix() for file in files}
    if actual != set(paths):
        raise RuntimeError(f"Incomplete files in {label}: missing {set(paths) - actual}; extra {actual - set(paths)}")
    for file in files:
        stats = file["statistics"]
        if not stats.get("templated_chars") or not stats.get("raw_segments"):
            raise RuntimeError(f"Empty/skipped lint work in {label}: {file['filepath']}")
    violations = [dict(file=file["filepath"], **v) for file in files for v in file["violations"]]
    errors = [v for v in violations if v["code"] in {"TMP", "PRS", "LXR"}]
    if errors or returncode not in (0, 1):
        (RESULTS / f"{label}-errors.json").write_text(json.dumps(errors, indent=2))
        raise RuntimeError(f"Rejected {label}: {len(errors)} template/parse/lex errors, exit {returncode}")
    phases = defaultdict(float)
    with timing.open(encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            for key in ("templating", "lexing", "parsing", "linting"):
                phases[key] += float(row[key])
    signature = sorted((Path(v["file"]).as_posix(), v["code"], v["start_line_no"], v["start_line_pos"], v["description"]) for v in violations)
    result = {
        "runtime": runtime, "selection": selection, "mode": mode, "repeat": repeat,
        "wall_seconds": elapsed, "peak_tree_rss_mib": peak_rss / 2**20,
        "peak_tree_private_mib": peak_private / 2**20, "max_processes": max_processes,
        "file_count": len(files), "violation_count": len(violations),
        "rendered_chars": sum(file["statistics"]["templated_chars"] for file in files),
        "raw_segments": sum(file["statistics"]["raw_segments"] for file in files),
        "violation_codes": dict(Counter(v["code"] for v in violations)),
        "violation_sha256": hashlib.sha256(json.dumps(signature).encode()).hexdigest(),
        "returncode": returncode, "file_phase_seconds": dict(phases), "command": command,
    }
    with (RESULTS / "measurements.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(result) + "\n")
    print(f"{label}: {elapsed:.3f}s, {len(files)} files, {len(violations)} violations, {peak_private / 2**20:.0f} MiB private", flush=True)
    return result


def summarise() -> None:
    groups = defaultdict(list)
    for line in (RESULTS / "measurements.jsonl").read_text().splitlines():
        row = json.loads(line)
        if row["mode"] in {"cleared", "repeated"}:
            groups[(row["mode"], row["selection"], row["runtime"])].append(row)
    summary = []
    for (mode, selection, runtime), rows in sorted(groups.items()):
        walls = [r["wall_seconds"] for r in rows]
        summary.append({
            "mode": mode, "selection": selection, "runtime": runtime, "n": len(rows),
            "median_seconds": statistics.median(walls), "min_seconds": min(walls),
            "max_seconds": max(walls), "stdev_seconds": statistics.stdev(walls) if len(walls) > 1 else 0,
            "median_peak_private_mib": statistics.median(r["peak_tree_private_mib"] for r in rows),
            "file_count": rows[0]["file_count"],
            "violation_counts": sorted({r["violation_count"] for r in rows}),
            "violation_signatures": sorted({r["violation_sha256"] for r in rows}),
        })
    (RESULTS / "summary.json").write_text(json.dumps(summary, indent=2))
    with (RESULTS / "summary.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--validate", action="store_true")
    parser.add_argument("--runtime", choices=["dbt1", "dbt2", "both"], default="both")
    parser.add_argument("--selection", nargs="+", default=["one-small", "one-large", "one-templated", "five-mixed", "five-incremental", "all"])
    parser.add_argument("--modes", nargs="+", default=["cleared", "repeated"])
    parser.add_argument("--repetitions", type=int, default=7)
    parser.add_argument("--summarise", action="store_true")
    args = parser.parse_args()
    if args.summarise:
        summarise()
        return
    runtimes = ["dbt1", "dbt2"] if args.runtime == "both" else [args.runtime]
    rng = random.Random(20261107)
    for mode in (["validation"] if args.validate else args.modes):
        if mode == "repeated":
            for runtime in runtimes:
                execute(runtime, "one-small", "warmup", 0)
        for repeat in range(1, (1 if args.validate else args.repetitions) + 1):
            selections = args.selection.copy()
            rng.shuffle(selections)
            for selection in selections:
                order = runtimes.copy()
                rng.shuffle(order)
                for runtime in order:
                    execute(runtime, selection, mode, repeat)
    if not args.validate:
        summarise()


if __name__ == "__main__":
    main()
