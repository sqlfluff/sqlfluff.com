{{ config(materialized='ephemeral') }}

select
    event_id,
    customer_id,
    event_type,
    amount,
    event_date
from {{ ref('stg_events_04') }}
where amount > 0
