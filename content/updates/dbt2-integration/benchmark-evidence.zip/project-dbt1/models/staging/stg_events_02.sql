select
    event_id,
    customer_id,
    event_type,
    amount,
    event_date
from {{ source('raw', 'events') }}
where event_id % 10 = 2
