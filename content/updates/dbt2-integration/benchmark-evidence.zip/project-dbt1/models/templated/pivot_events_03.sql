{{ config(materialized='table') }}
{% set moduli = range(2, 62) %}

select
    customer_id,
    event_date,
    {{ dbt_utils.generate_surrogate_key(['customer_id', 'event_date']) }} as group_key,
    {% for modulus in moduli %}{{ bucket(modulus) }} as bucket_{{ modulus }},
    {% endfor %}sum(amount) as total_amount
from {{ ref('dim_events_03') }}
{{ dbt_utils.group_by(n=2) }}
