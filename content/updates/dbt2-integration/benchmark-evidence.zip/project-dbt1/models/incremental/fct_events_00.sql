{{ config(materialized='incremental', unique_key='event_id', incremental_strategy='delete+insert') }}

select
    event_id,
    customer_id,
    event_type,
    {{ money('amount') }} as amount,
    event_date,
    {{ dbt_utils.generate_surrogate_key(['event_id', 'customer_id']) }} as event_key
from {{ ref('stg_events_00') }}
{% if is_incremental() %}
    where event_date >= (select max(event_date) from {{ this }})
{% else %}
    where event_id >= 0
{% endif %}
