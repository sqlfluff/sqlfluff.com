{{ config(materialized='view') }}

select
    event_id,
    customer_id,
    event_type,
    {{ money('amount') }} as amount,
    event_date,
    {{ dbt_utils.generate_surrogate_key(['event_id', 'customer_id']) }} as event_key
from {{ ref('stg_events_04') }}
