{% macro money(expression, scale=2) -%}
    round(cast({{ expression }} as decimal(18, 4)), {{ scale }})
{%- endmacro %}

{% macro conditional_sum(value, column, kind) -%}
    {% set predicate = column ~ " = '" ~ kind ~ "'" %}
    {{ return('sum(case when ' ~ predicate ~ ' then ' ~ value ~ ' else 0 end)') }}
{%- endmacro %}

{% macro bucket(modulus) -%}
    {% if modulus % 2 == 0 %}
        sum(case when event_id % {{ modulus }} = 0 then {{ money('amount') }} else 0 end)
    {% else %}
        sum(case when event_id % {{ modulus }} = 1 then amount else 0 end)
    {% endif %}
{%- endmacro %}
