# Windows dbt templater benchmark

This directory compares real, fresh-process `sqlfluff lint` commands against the
legacy dbt Core 1.x templater and the experimental dbt 2 trace consumer. All work
and findings remain local. Neither live PR is modified or commented on.

## Fixed source revisions

- dbt exporter: `b09632e1967c93be062253b010b657c98c8e5204`,
  <https://github.com/dbt-labs/dbt/pull/16870>.
- SQLFluff, shared by both environments: `6b387685567e23167ea25a94226a5219e7471c3a`,
  <https://github.com/sqlfluff/sqlfluff/pull/8854>.
- dbt_utils: 1.3.3, pinned in the generated package lock.
- Exact Python dependency versions are saved under `results/`.

## Workload and controls

`generate_project.py` creates two independent copies of the same 100-model
project: 10 staging, 20 small macro/dbt_utils, 30 medium aggregate/window, 20 large
CTE/join, 10 inline-loop/nested-macro/conditional/dbt_utils, five ephemeral, and five
incremental models. There are 8,825 source lines. Source and rendered inventories
and the exact path selections are saved under `results/`.

The local DuckDB database contains deterministic seed data. Incremental target
tables exist before linting, exercising the `is_incremental()` branch. Database
setup/build time is excluded from lint timings. Source/configuration is identical
apart from required runtime, project-path and templater settings. SQLFluff uses
the Python parser, one lint worker, all default rules, no file-size skipping, and
explicit isolated configuration. dbt uses one thread. Python is 3.13.15 on Windows.

Measurements include Python/SQLFluff startup, dbt work, source mapping, linting,
JSON result production and temporary-artifact cleanup. They exclude dependency
installation and Rust compilation. Each sample starts a new SQLFluff process;
this does not measure a resident editor service. Filesystem caches are not flushed
and this is not an OS-cold benchmark.

Two artifact conditions are compared: `cleared` deletes only that benchmark
project's target/log directories before each sample; `repeated` retains artifacts
between fresh-process invocations. The dbt2 plugin intentionally uses a new
temporary target for every invocation, so it cannot reuse the project's partial
parse cache. This difference is part of the implementation being measured.

The controller samples process-tree private memory and working set every 25 ms.
Private memory is the primary Windows memory metric; summed working sets can count
shared pages more than once. These sampled peaks are approximate. SQLFluff's
per-file timing CSVs do not include all batch compilation and startup work, so
they must not be mistaken for end-to-end template times.

Correctness checks reject missing output files and any templating, lexing or
parsing errors, and retain lint diagnostic signatures. Ordinary style violations
are permitted and recorded. Exclusions, if needed, apply to both runtimes and
are documented in the report.

The original ten block-indented loop/capture stress variants were excluded after
they produced duplicated/inconsistent LT02 diagnostics in the experimental
consumer. Their SQL results were equivalent under both renderers. The final ten
inline-loop replacements still generate 60 aggregate columns through conditional
and nested macros. Original sources, small reproducers and diagnostics are saved
under `results/excluded-sources` and `results/original-validation`. Neither PR was
patched to accommodate this finding.

## Reproduce

Use the saved dependency lists to recreate the two isolated environments. The
source export in `vendor/sqlfluff-pr` is an archive of the fixed SQLFluff commit,
installed normally into both environments (with the appropriate plugin).

Build the actual upstream dbt checkout with its documented maturin wheel build:

```powershell
$env:PROTOC = '<absolute path to protoc.exe>'
$env:CARGO_BUILD_JOBS = '4'
python -m maturin build --manifest-path crates/dbt-sa-python/Cargo.toml --release --out <benchmark-dir>/dist
```

The normal release profile uses opt-level 3, ThinLTO and one codegen unit. No Rust
source changes are required by this benchmark. Build dependencies are captured in
the saved `Cargo.lock`. Install the resulting Windows ABI3 wheel into `env-dbt2`.
On this machine the build uses the repository-selected Rust 1.96.1 toolchain.
The `protoc-wheel-0` 30.2 launcher required replacement with its bundled native
`protoc.exe`; its bundled Google include files were copied alongside the tool.
The compiler runs successfully in the native build environment. These are local
tool setup changes, not patches to dbt or SQLFluff.

```powershell
env-tools/Scripts/python.exe generate_project.py
# Resolve packages with dbt1 deps; copy the pinned dbt_packages and lock to dbt2.
# Run dbt seed/run from inside project-dbt1 (the database path is relative).
# Run incremental models a second time, then copy the database to project-dbt2.
env-tools/Scripts/python.exe run_benchmarks.py --validate
env-dbt1/Scripts/python.exe capture_rendering.py dbt1
env-dbt2/Scripts/python.exe capture_rendering.py dbt2
env-dbt1/Scripts/python.exe compare_rendered.py
env-tools/Scripts/python.exe verify_final_workload.py
env-tools/Scripts/python.exe run_benchmarks.py --repetitions 7
env-tools/Scripts/python.exe audit_results.py
env-tools/Scripts/python.exe run_benchmarks.py --summarise
env-tools/Scripts/python.exe report_results.py
```

Do not run the timing phase concurrently with a Rust build or another benchmark.
Selection/runtime order is shuffled reproducibly. Raw results append to
`results/measurements.jsonl`; use a fresh output location for an independent rerun.
Validation observations are labelled and excluded from reported timing summaries.
