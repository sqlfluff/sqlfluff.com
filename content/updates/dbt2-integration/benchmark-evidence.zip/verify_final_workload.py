"""Fail fast on data, diagnostic, source or selection mismatches before timing."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def main() -> None:
    selections = json.loads((RESULTS / "selections.json").read_text())
    parity = []
    for name, paths in selections.items():
        files = [json.loads((ROOT / "logs" / f"validation-{name}-{runtime}-01.json").read_text()) for runtime in ("dbt1", "dbt2")]
        signatures = []
        for output in files:
            assert len(output) == len(paths), name
            signature = sorted((Path(file["filepath"]).as_posix(), violation["code"], violation["start_line_no"], violation["start_line_pos"], violation["description"]) for file in output for violation in file["violations"])
            assert not any(item[1] in {"TMP", "PRS", "LXR"} for item in signature), name
            signatures.append(signature)
        assert signatures[0] == signatures[1], f"Diagnostic difference in {name}"
        parity.append({"selection": name, "file_count": len(paths), "diagnostic_count": len(signatures[0]), "same_diagnostics": True})
    comparison = json.loads((RESULTS / "rendered-comparison.json").read_text())
    assert len(comparison) == 100 and all(row["same_results"] for row in comparison)
    source_count = 0
    for subdir in ("models", "macros", "seeds"):
        one = ROOT / "project-dbt1" / subdir
        two = ROOT / "project-dbt2" / subdir
        for path in one.rglob("*"):
            if path.is_file():
                assert path.read_bytes() == (two / path.relative_to(one)).read_bytes(), path
                source_count += 1
    assert len(list((ROOT / "project-dbt1/models").rglob("*.sql"))) == 100
    assert len(list((ROOT / "project-dbt2/models").rglob("*.sql"))) == 100
    database_hashes = [hashlib.sha256((ROOT / f"project-{runtime}/benchmark.duckdb").read_bytes()).hexdigest() for runtime in ("dbt1", "dbt2")]
    assert database_hashes[0] == database_hashes[1]
    (RESULTS / "final-correctness.json").write_text(json.dumps({"diagnostic_parity": parity, "identical_source_files": source_count, "equivalent_rendered_results": len(comparison), "database_sha256": database_hashes[0]}, indent=2))
    print(f"Verified {source_count} identical workload files, 100 equivalent query results, identical database files, and diagnostic parity for all {len(parity)} selections", flush=True)


if __name__ == "__main__":
    main()
