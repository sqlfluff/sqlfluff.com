"""Audit the completed matrix, diagnostic parity and amount of lint work."""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def main() -> None:
    groups = defaultdict(list)
    for line in (RESULTS / "measurements.jsonl").read_text().splitlines():
        row = json.loads(line)
        if row["mode"] in {"cleared", "repeated"}:
            groups[(row["mode"], row["selection"], row["runtime"])].append(row)
    assert len(groups) == 24, len(groups)
    full_diagnostics = defaultdict(set)
    for key, rows in groups.items():
        assert len(rows) == 7 and {row["repeat"] for row in rows} == set(range(1, 8)), key
        assert len({row["violation_sha256"] for row in rows}) == 1, key
        assert len({row["rendered_chars"] for row in rows}) == 1, key
        assert len({row["raw_segments"] for row in rows}) == 1, key
        assert all(row["wall_seconds"] > sum(row["file_phase_seconds"].values()) for row in rows), key
        assert all(row["peak_tree_private_mib"] > 0 and row["peak_tree_rss_mib"] > 0 for row in rows), key
        for row in rows:
            label = f"{row['mode']}-{row['selection']}-{row['runtime']}-{row['repeat']:02}"
            output = json.loads((ROOT / "logs" / f"{label}.json").read_text())
            diagnostics = sorted((Path(file["filepath"]).as_posix(), file["violations"]) for file in output)
            full_diagnostics[(row["mode"], row["selection"])].add(json.dumps(diagnostics, sort_keys=True))
    assert all(len(signatures) == 1 for signatures in full_diagnostics.values()), "Full diagnostic objects differ"
    for mode in ("cleared", "repeated"):
        for selection in json.loads((RESULTS / "selections.json").read_text()):
            one = groups[(mode, selection, "dbt1")]
            two = groups[(mode, selection, "dbt2")]
            assert {row["violation_sha256"] for row in one} == {row["violation_sha256"] for row in two}, (mode, selection)
            assert one[0]["rendered_chars"] - two[0]["rendered_chars"] == one[0]["file_count"], (mode, selection)
            assert all(row["max_processes"] >= 2 for row in two), (mode, selection)
    audit = {
        "status": "passed", "groups": len(groups), "repetitions_per_group": 7,
        "timed_process_invocations": sum(len(rows) for rows in groups.values()),
        "individual_file_lints": sum(row["file_count"] for rows in groups.values() for row in rows),
        "diagnostics_identical_across_runtimes_and_repetitions": True,
        "full_diagnostic_objects_compared_including_end_positions_and_fix_suggestions": True,
        "constant_rendered_characters_and_segments_within_each_case": True,
        "rendered_character_difference": "Legacy output retains one additional trailing newline per file; data results are equivalent for all 100 models.",
        "dbt2_child_process_observed_in_every_sample": True,
    }
    (RESULTS / "audit.json").write_text(json.dumps(audit, indent=2))
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
