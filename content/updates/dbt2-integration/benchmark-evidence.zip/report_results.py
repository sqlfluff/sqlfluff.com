"""Produce a standalone report and chart from the saved benchmark observations."""

from __future__ import annotations

import html
import json
import statistics
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, NullFormatter, ScalarFormatter

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
LABELS = {
    "one-small": "1 small model",
    "one-large": "1 large model",
    "one-templated": "1 loop-heavy model",
    "five-mixed": "5 mixed models",
    "five-incremental": "5 incremental models",
    "all": "Whole project",
}


def main() -> None:
    summary = json.loads((RESULTS / "summary.json").read_text())
    lookup = {(r["mode"], r["selection"], r["runtime"]): r for r in summary}
    rows = [json.loads(line) for line in (RESULTS / "measurements.jsonl").read_text().splitlines()]
    provenance = json.loads((RESULTS / "provenance.json").read_text())
    groups = defaultdict(list)
    for row in rows:
        if row["mode"] in ("cleared", "repeated"):
            groups[(row["mode"], row["selection"], row["runtime"])].append(row)
    comparisons = []
    for mode in ("cleared", "repeated"):
        for selection in LABELS:
            if (mode, selection, "dbt1") not in lookup or (mode, selection, "dbt2") not in lookup:
                continue
            one = lookup[(mode, selection, "dbt1")]
            two = lookup[(mode, selection, "dbt2")]
            comparisons.append({"mode": mode, "selection": selection, "file_count": one["file_count"], "dbt1_median_seconds": one["median_seconds"], "dbt2_median_seconds": two["median_seconds"], "speedup": one["median_seconds"] / two["median_seconds"], "time_reduction_percent": 100 * (1 - two["median_seconds"] / one["median_seconds"])})
    (RESULTS / "comparisons.json").write_text(json.dumps(comparisons, indent=2))
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.8), sharey=True)
    fig.set_facecolor("#fafafa")
    for ax, mode in zip(axes, ("cleared", "repeated")):
        selections = [key for key in LABELS if (mode, key, "dbt1") in lookup and (mode, key, "dbt2") in lookup]
        for runtime, offset, color, name in (("dbt1", -0.13, "#4766a7", "dbt 1 + legacy templater"), ("dbt2", 0.13, "#da7133", "dbt 2 PR + trace templater")):
            values = [lookup[(mode, key, runtime)] for key in selections]
            medians = [v["median_seconds"] for v in values]
            ax.errorbar(medians, [i + offset for i in range(len(values))], xerr=[[v["median_seconds"] - v["min_seconds"] for v in values], [v["max_seconds"] - v["median_seconds"] for v in values]], fmt="o", color=color, capsize=3, label=name)
        ax.set_yticks(range(len(selections)), [LABELS[k] for k in selections])
        ax.set_xscale("log")
        ax.set_xlim(1, 65)
        ax.xaxis.set_major_locator(FixedLocator([1, 2, 5, 10, 20, 50]))
        ax.xaxis.set_major_formatter(ScalarFormatter())
        ax.xaxis.set_minor_formatter(NullFormatter())
        ax.set_xlabel("End-to-end seconds (log scale; lower is faster)")
        ax.set_title("Project artifacts cleared" if mode == "cleared" else "Repeated fresh-process runs")
        ax.grid(axis="x", alpha=.2, which="both")
        ax.set_facecolor("#fafafa")
        ax.spines[["top", "right"]].set_visible(False)
    axes[0].invert_yaxis()
    axes[1].legend(loc="upper right", fontsize=9)
    fig.suptitle("SQLFluff linting on Windows: dbt 1 vs experimental dbt 2", fontsize=15, fontweight="bold")
    fig.text(.5, .01, "Dots: medians • Whiskers: observed minimum–maximum • One lint worker • Python parser • All default rules", ha="center", fontsize=9)
    fig.tight_layout(rect=(0, .035, 1, .94))
    fig.savefig(RESULTS / "benchmark.png", dpi=180)
    fig.savefig(RESULTS / "benchmark.svg")
    sections = []
    for mode in ("repeated", "cleared"):
        body = []
        for c in comparisons:
            if c["mode"] != mode:
                continue
            one = lookup[(mode, c["selection"], "dbt1")]
            two = lookup[(mode, c["selection"], "dbt2")]
            body.append(f"<tr><td>{LABELS[c['selection']]} ({c['file_count']})</td><td>{one['median_seconds']:.3f}<small>{one['min_seconds']:.3f}–{one['max_seconds']:.3f}</small></td><td>{two['median_seconds']:.3f}<small>{two['min_seconds']:.3f}–{two['max_seconds']:.3f}</small></td><td>{c['speedup']:.2f}×</td><td>{c['time_reduction_percent']:.1f}%</td><td>{one['median_peak_private_mib']:.0f} / {two['median_peak_private_mib']:.0f}</td><td>{one['n']} / {two['n']}</td></tr>")
        sections.append(f"<h2>{'Repeated fresh-process runs' if mode == 'repeated' else 'Project artifacts cleared before each run'}</h2><table><thead><tr><th>Workload (files)</th><th>dbt 1 seconds</th><th>dbt 2 seconds</th><th>Speed ratio</th><th>Less elapsed time</th><th>Private MiB<br>dbt 1 / dbt 2</th><th>Samples<br>dbt 1 / dbt 2</th></tr></thead><tbody>{''.join(body)}</tbody></table><p class='note'>Seconds show median, with observed minimum–maximum below. Ratio above 1 means dbt 2 is faster. Memory is the median sampled peak of summed process-tree private memory.</p>")
    phase_body = []
    for runtime in ("dbt1", "dbt2"):
        for selection in ("one-small", "five-mixed", "all"):
            measurements = groups[("repeated", selection, runtime)]
            if not measurements:
                continue
            medians = {key: statistics.median(r["file_phase_seconds"][key] for r in measurements) for key in ("templating", "lexing", "parsing", "linting")}
            total_file = statistics.median(sum(r["file_phase_seconds"].values()) for r in measurements)
            wall = statistics.median(r["wall_seconds"] for r in measurements)
            phase_body.append(f"<tr><td>{runtime}</td><td>{LABELS[selection]}</td>" + "".join(f"<td>{medians[k]:.3f}</td>" for k in medians) + f"<td>{wall - total_file:.3f}</td><td>{wall:.3f}</td></tr>")
    findings = (RESULTS / "findings.html").read_text(encoding="utf-8") if (RESULTS / "findings.html").exists() else "<p>See the saved validation logs and raw diagnostic signatures.</p>"
    chart = (RESULTS / "benchmark.svg").read_text(encoding="utf-8")
    chart = chart[chart.index("<svg"):]
    primary = {r["selection"]: r for r in comparisons if r["mode"] == "repeated"}
    lead = "For repeated fresh-process CLI runs, median elapsed time fell " + "; ".join(
        f"from <strong>{primary[key]['dbt1_median_seconds']:.2f} to {primary[key]['dbt2_median_seconds']:.2f} seconds</strong> for {label}"
        for key, label in (("one-small", "one small model"), ("five-mixed", "five mixed models"), ("all", "all 100 models"))
    ) + ". The timing breakdown indicates that the shared SQLFluff parsing and linting work dominates the whole-project case."
    report = f"""<!doctype html><html><head><meta charset="utf-8"><title>Windows dbt templater benchmark</title><style>
body{{font:16px/1.55 system-ui,sans-serif;max-width:1180px;margin:40px auto;padding:0 24px;color:#202733}}h1{{line-height:1.15}}h2{{margin-top:2em}}table{{border-collapse:collapse;width:100%;font-size:14px}}th,td{{padding:10px;border-bottom:1px solid #dfe3e8;text-align:right}}th:first-child,td:first-child{{text-align:left}}small{{display:block;color:#6a7380}}.note{{font-size:14px;color:#596372}}svg{{max-width:100%;height:auto}}code{{background:#f0f2f5;padding:2px 4px}}pre{{white-space:pre-wrap;background:#f5f6f8;padding:16px}}a{{color:#285b9e}}</style></head><body>
<h1>Windows dbt templater performance</h1><p>Local measurements on 7 November 2026. Both configurations use SQLFluff 4.5.0 from the same PR commit. The dbt 2 engine is built locally from the actual exporter PR, using the optimized release profile.</p>
<p>{lead}</p>
{chart}
{''.join(sections)}
<h2>Correctness and exclusions</h2>{findings}
<h2>Where the time goes</h2><table><thead><tr><th>Runtime</th><th>Workload</th><th>Per-file template</th><th>Lex</th><th>Parse</th><th>Lint</th><th>Other wall time</th><th>Total wall</th></tr></thead><tbody>{''.join(phase_body)}</tbody></table>
<p>These are medians in seconds from repeated runs. SQLFluff’s per-file template timers exclude the dbt2 batch compile in <code>sequence_files()</code>, and exclude legacy manifest initialization done there. “Other wall time” includes startup/imports, that batch/manifest work, output and cleanup; it is not a direct compilation timer. Independent medians need not add exactly.</p>
<h2>Method and practical limits</h2><ul><li>100 source models: 10 staging, 20 small macro/dbt_utils, 30 medium aggregate/window, 20 large CTE/join, 10 inline-loop/nested-macro/branch, five ephemeral and five incremental; 8,825 source lines. See correctness notes for excluded original variants.</li><li>Same source and seed data, parser, default rule set and one lint worker. dbt uses one thread. No file-size skipping. Incremental target relations already exist.</li><li>Each sample starts a fresh Python process. Timing includes startup, dbt work, mapping, linting, JSON output and cleanup, and excludes build/install/database setup. This measures CLI use, not a long-lived editor process.</li><li>Artifact-cleared runs delete only the local project target/log directories; repeated runs retain them. dbt2 always compiles to a fresh temporary target by design. OS filesystem caches are not flushed.</li><li>Runtime and selection order are shuffled with seed 20261107. No benchmark runs overlap each other or the Rust build. Validation observations are excluded from timing summaries.</li><li>Process-tree memory is sampled every 25 ms. Private-memory peaks avoid summing shared working-set pages, but remain approximate and are affected by sampling.</li><li>This synthetic local DuckDB workload cannot establish results for other adapters, large external packages, warehouse latency or untested templating constructs.</li></ul>
<h2>Machine, builds and reproduction</h2><pre>{html.escape(json.dumps(provenance, indent=2))}</pre>
<p><a href="requirements-dbt1.txt">dbt 1 packages</a> · <a href="requirements-dbt2.txt">dbt 2 packages</a> · <a href="Cargo.lock">Rust lockfile</a> · <a href="measurements.jsonl">Raw measurements and exact commands</a> · <a href="summary.csv">Summary CSV</a> · <a href="model-inventory.json">Model inventory</a> · <a href="selections.json">Selections</a> · <a href="../README.md">Reproduction notes</a></p>
</body></html>"""
    (RESULTS / "REPORT.html").write_text(report, encoding="utf-8")
    print(json.dumps(comparisons, indent=2))


if __name__ == "__main__":
    main()
