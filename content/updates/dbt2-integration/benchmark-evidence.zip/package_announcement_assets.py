"""Package public benchmark evidence and the companion website assets."""

from __future__ import annotations

import shutil
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "announcement-assets"


def public_text(path: Path) -> bytes:
    text = path.read_text(encoding="utf-8-sig")
    for prefix in (str(ROOT).replace("\\", "\\\\"), ROOT.as_posix(), str(ROOT)):
        text = text.replace(prefix, "<BENCHMARK_DIR>")
    return text.encode("utf-8")


def main() -> None:
    OUTPUT.mkdir(exist_ok=True)
    shutil.copyfile(ROOT / "results/benchmark.png", OUTPUT / "benchmark.png")
    shutil.copyfile(ROOT / "results/summary.csv", OUTPUT / "summary.csv")
    selected = [ROOT / "README.md", *ROOT.glob("*.py")]
    selected += [p for p in (ROOT / "results").rglob("*") if p.is_file() and p.suffix in {".json", ".jsonl", ".csv", ".txt", ".sql"}]
    selected += [ROOT / "results/Cargo.lock"]
    for runtime in ("dbt1", "dbt2"):
        project = ROOT / f"project-{runtime}"
        selected += [project / name for name in ("dbt_project.yml", "profiles.yml", "packages.yml", "package-lock.yml", "lint.ini")]
        for directory in ("models", "macros", "seeds"):
            selected += [p for p in (project / directory).rglob("*") if p.is_file()]
    selected += list((ROOT / "logs").glob("cleared-*.json"))
    selected += list((ROOT / "logs").glob("repeated-*.json"))
    evidence = OUTPUT / "benchmark-evidence.zip"
    with ZipFile(evidence, "w", ZIP_DEFLATED) as bundle:
        for path in sorted(set(selected)):
            bundle.writestr(path.relative_to(ROOT).as_posix(), public_text(path))
    archive = ROOT / "announcement-assets.zip"
    with ZipFile(archive, "w", ZIP_DEFLATED) as bundle:
        for path in sorted(OUTPUT.iterdir()):
            bundle.write(path, path.name)
    for path in (evidence, archive):
        with ZipFile(path) as bundle:
            assert bundle.testzip() is None
            print(f"{path.name}: {len(bundle.namelist())} files, {path.stat().st_size:,} bytes")


if __name__ == "__main__":
    main()
