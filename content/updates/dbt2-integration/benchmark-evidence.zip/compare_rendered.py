"""Compare actual renderer outputs by executing them against identical local data."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

import duckdb

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def main() -> None:
    paths = json.loads((RESULTS / "selections.json").read_text())["all"]
    outcomes = []
    conn = duckdb.connect(str(ROOT / "project-dbt1/benchmark.duckdb"), read_only=True)
    for path in paths:
        queries = [(RESULTS / f"rendered-{runtime}" / path).read_text(encoding="utf-8") for runtime in ("dbt1", "dbt2")]
        # The exporter contract deliberately precedes ephemeral CTE injection.
        # Reconstruct only those CTEs for this additional execution check. This
        # reconstruction is never used for the performance measurements.
        ephemeral_names = []
        for index, runtime in enumerate(("dbt1", "dbt2")):
            query = queries[index]
            names = sorted(set(re.findall(r"__dbt__cte__(eph_events_\d+)", query)))
            if names:
                ephemeral_names = names
                ctes = []
                for name in names:
                    sql = (RESULTS / f"rendered-{runtime}/models/ephemeral" / f"{name}.sql").read_text()
                    ctes.append(f"__dbt__cte__{name} as ({sql})")
                match = re.match(r"\s*with\s+", query, re.I)
                if match:
                    query = "with " + ", ".join(ctes) + ", " + query[match.end():]
                else:
                    query = "with " + ", ".join(ctes) + " " + query
                queries[index] = query
        outputs = []
        descriptions = []
        for query in queries:
            result = conn.execute(query)
            descriptions.append([column[0] for column in result.description])
            outputs.append(sorted(result.fetchall(), key=repr))
        same = descriptions[0] == descriptions[1] and outputs[0] == outputs[1]
        outcomes.append({"path": path, "same_results": same, "dbt1_rows": len(outputs[0]), "dbt2_rows": len(outputs[1]), "text_equal": queries[0] == queries[1], "injected_ephemeral_for_execution_check": ephemeral_names, "result_sha256": [hashlib.sha256(repr(out).encode()).hexdigest() for out in outputs]})
        if not same:
            print(f"MISMATCH: {path}: {descriptions[0]} / {descriptions[1]}")
    conn.close()
    (RESULTS / "rendered-comparison.json").write_text(json.dumps(outcomes, indent=2))
    failures = [outcome for outcome in outcomes if not outcome["same_results"]]
    print(f"Equivalent query results for {len(outcomes) - len(failures)}/{len(outcomes)} models")
    if failures:
        raise RuntimeError("Renderer result mismatch; see rendered-comparison.json")


if __name__ == "__main__":
    main()
