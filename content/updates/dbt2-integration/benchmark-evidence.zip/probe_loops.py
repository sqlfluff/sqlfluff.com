"""Locally narrow diagnostic differences without modifying either PR."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

for runtime in ("dbt1", "dbt2"):
    project = ROOT / f"project-{runtime}"
    original = (ROOT / "results/excluded-sources/original-stress/pivot_events_00.sql").read_text()
    variants = {
        "simple": """select
    customer_id,
    {% for modulus in range(2, 32) %}
        sum(case when event_id % {{ modulus }} = 0 then amount else 0 end) as bucket_{{ modulus }},
    {% endfor %}
    sum(amount) as total_amount
from {{ ref('dim_events_00') }}
group by customer_id
""",
        "inline": """select
    customer_id,
    {% for modulus in range(2, 32) %}sum(case when event_id % {{ modulus }} = 0 then amount else 0 end) as bucket_{{ modulus }},
    {% endfor %}sum(amount) as total_amount
from {{ ref('dim_events_00') }}
group by customer_id
""",
        "nested": """select
    customer_id,
    {% for modulus in range(2, 32) %}
        {% for parity in range(2) %}
            sum(case when event_id % {{ modulus }} = {{ parity }} then amount else 0 end) as bucket_{{ modulus }}_{{ parity }},
        {% endfor %}
    {% endfor %}
    sum(amount) as total_amount
from {{ ref('dim_events_00') }}
group by customer_id
""",
        "no_capture": original.replace("{% set projected %}\n    {{ dimensions | join(', ') }}\n{% endset %}", "").replace("{{ projected }}", "customer_id,\n    event_date"),
    }
    for name, source in variants.items():
        path = project / f"models/probes/probe_{name}.sql"
        path.parent.mkdir(exist_ok=True)
        path.write_text(source, encoding="utf-8", newline="\n")
selections = json.loads((ROOT / "results/selections.json").read_text())
selections["probe-loops"] = [f"models/probes/probe_{name}.sql" for name in variants]
(ROOT / "results/selections.json").write_text(json.dumps(selections, indent=2))
