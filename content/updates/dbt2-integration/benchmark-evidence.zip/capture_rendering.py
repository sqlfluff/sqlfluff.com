"""Save actual templater output for an untimed correctness comparison."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from sqlfluff.core import FluffConfig

ROOT = Path(__file__).resolve().parent


def main() -> None:
    runtime = sys.argv[1]
    project = ROOT / f"project-{runtime}"
    os.chdir(project)
    config = FluffConfig.from_path(str(project), extra_config_path=str(project / "lint.ini"), ignore_local_config=True)
    templater = config.get_templater()
    paths = json.loads((ROOT / "results/selections.json").read_text())["all"]
    ordered = templater.sequence_files([str(project / path) for path in paths], config=config)
    inventory = []
    for fname in ordered:
        path = Path(fname)
        relative = path.relative_to(project).as_posix()
        rendered, errors = templater.process(in_str=path.read_text(encoding="utf-8"), fname=str(path), config=config)
        if errors or rendered is None:
            raise RuntimeError(f"{relative}: {errors}")
        destination = ROOT / "results" / f"rendered-{runtime}" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(rendered.templated_str, encoding="utf-8", newline="\n")
        inventory.append({"path": relative, "source_chars": len(rendered.source_str), "rendered_chars": len(rendered.templated_str), "slices": len(rendered.sliced_file)})
    (ROOT / "results" / f"rendered-{runtime}.json").write_text(json.dumps(inventory, indent=2))
    print(f"Captured {len(inventory)} rendered models", flush=True)


if __name__ == "__main__":
    main()
