"""Release-to-release CLI lint benchmark, using public fixtures only."""
import argparse
from collections import Counter
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import tarfile
import time

ROOT = Path(__file__).resolve().parent
REPO = Path(os.environ.get('SQLFLUFF_REPO', Path.cwd()))
VERSIONS = ['4.4.0', '4.5.0']
DIALECTS = ['ansi', 'snowflake', 'tsql']


def prepare():
    raw = subprocess.check_output(['git', 'archive', '4.4.0', 'test/fixtures/dialects'], cwd=REPO)
    files = []
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for dialect in DIALECTS:
            candidates = [m for m in archive.getmembers() if m.isfile()
                          and m.name.startswith(f'test/fixtures/dialects/{dialect}/')
                          and m.name.endswith('.sql') and 0 < m.size <= 20000]
            candidates.sort(key=lambda m: (m.size, m.name))
            chosen = [candidates[round(i * (len(candidates)-1) / 23)] for i in range(24)]
            for member in chosen:
                data = archive.extractfile(member).read()
                target = ROOT / 'corpus' / dialect / Path(member.name).name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
                files.append({'path': target.relative_to(ROOT).as_posix(), 'source': member.name,
                              'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    (ROOT / 'manifest.json').write_text(json.dumps({
        'fixture_ref': '4.4.0', 'fixture_commit': subprocess.check_output(
            ['git', 'rev-parse', '4.4.0^{}'], cwd=REPO, text=True).strip(),
        'selection': '24 files per dialect, evenly spaced ranks by (byte length, path), '
                     'from nonempty .sql fixtures <=20,000 bytes; before seeing timings',
        'files': files}, indent=2))
    (ROOT / 'benchmark.sqlfluff').write_text(
        '[sqlfluff]\ntemplater = raw\nuse_rust_parser = False\nuse_rust_rules = False\n'
        'large_file_skip_byte_limit = 0\nlarge_file_skip_char_limit = 0\n')
    benchmark_python = subprocess.check_output(
        [str(ROOT / 'env-4.5.0/Scripts/python.exe'), '-c',
         'import sys; print(sys.version)'], text=True).strip()
    metadata = {'python': benchmark_python, 'controller_python': platform.python_version(), 'platform': platform.platform(),
                'logical_processors': os.cpu_count(), 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'scope': 'fresh-process CLI lint wall time including startup, parsing, rules and JSON output; '
                         'raw templater, Python parser, default rules; no fixing',
                'conditions': 'desktop machine; other applications running; warm filesystem cache; '
                              'one warm-up per version/cell, then five alternating-order pairs'}
    (ROOT / 'environment.json').write_text(json.dumps(metadata, indent=2))


def run(version, dialect, processes, label):
    out = ROOT / 'raw' / f'{dialect}-p{processes}-{label}-{version}'
    out.parent.mkdir(exist_ok=True)
    executable = ROOT / f'env-{version}' / 'Scripts/python.exe'
    args = [str(executable), '-m', 'sqlfluff', 'lint', f'corpus/{dialect}',
            '--dialect', dialect, '--ignore-local-config', '--config', 'benchmark.sqlfluff',
            '--processes', str(processes), '--format', 'json', '--disable-progress-bar',
            '--persist-timing', str(out.with_suffix('.csv'))]
    env = os.environ.copy()
    env.pop('PYTHONPATH', None)
    env['PYTHONHASHSEED'] = '0'
    env['NO_COLOR'] = '1'
    start = time.perf_counter()
    result = subprocess.run(args, cwd=ROOT, env=env, capture_output=True, timeout=180)
    elapsed = time.perf_counter() - start
    out.with_suffix('.stdout.json').write_bytes(result.stdout)
    out.with_suffix('.stderr.txt').write_bytes(result.stderr)
    records = json.loads(result.stdout)
    assert result.returncode in (0, 1), result.stderr.decode(errors='replace')
    assert len(records) == 24, len(records)
    errors = Counter(v['code'] for r in records for v in r['violations'])
    for code in ['PRS', 'LXR', 'TMP']:
        assert errors[code] == 0, (dialect, version, code, errors[code])
    stderr = result.stderr.decode(errors='replace')
    assert not any(s in stderr.lower() for s in ['traceback', 'unable to lint', 'skipping file', 'exception']), stderr
    item = {'version': version, 'dialect': dialect, 'processes': processes,
            'label': label, 'seconds': elapsed, 'exit_code': result.returncode,
            'files': len(records), 'violations': sum(errors.values()), 'codes': dict(errors),
            'command': args[1:], 'stderr': stderr}
    out.with_suffix('.meta.json').write_text(json.dumps(item, indent=2))
    print(f'{dialect} p{processes} {label} {version}: {elapsed:.3f}s, {sum(errors.values())} violations', flush=True)
    return item


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pilot', action='store_true')
    args = parser.parse_args()
    if not (ROOT / 'manifest.json').exists():
        prepare()
    if args.pilot:
        for version in VERSIONS:
            run(version, 'ansi', 1, 'pilot')
        return
    results = []
    for dialect in DIALECTS:
        for processes in [1, 4]:
            for version in VERSIONS:
                run(version, dialect, processes, 'warmup')
            for repeat in range(5):
                order = VERSIONS if repeat % 2 == 0 else list(reversed(VERSIONS))
                for version in order:
                    results.append(run(version, dialect, processes, f'run{repeat+1}'))
                    (ROOT / 'results.json').write_text(json.dumps(results, indent=2))
    rows = []
    for dialect in DIALECTS:
        for processes in [1, 4]:
            groups = [[r['seconds'] for r in results if r['dialect'] == dialect
                       and r['processes'] == processes and r['version'] == version] for version in VERSIONS]
            a, b = map(statistics.median, groups)
            rows.append({'dialect': dialect, 'processes': processes, 'files': 24,
                         'v4_4_median_s': a, 'v4_5_median_s': b, 'time_reduction_pct': 100*(1-b/a),
                         'speedup': a/b, 'v4_4_min_s': min(groups[0]), 'v4_4_max_s': max(groups[0]),
                         'v4_5_min_s': min(groups[1]), 'v4_5_max_s': max(groups[1])})
    with (ROOT / 'summary.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(rows, indent=2), flush=True)


if __name__ == '__main__':
    main()
