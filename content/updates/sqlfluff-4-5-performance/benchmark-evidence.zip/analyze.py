"""Build shareable tables and figures from recorded benchmark observations."""
from collections import Counter
import hashlib
import html
import json
from pathlib import Path
import statistics
import zipfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
results = json.loads((ROOT / 'results.json').read_text())
manifest = json.loads((ROOT / 'manifest.json').read_text())
environment = json.loads((ROOT / 'environment.json').read_text())
assert len(results) == 60
assert all(r['files'] == 24 for r in results)
for file in manifest['files']:
    assert hashlib.sha256((ROOT / file['path']).read_bytes()).hexdigest() == file['sha256']
for result in results:
    version_prefix = result['version'].rsplit('.', 1)[0]
    records = json.loads((ROOT / f"raw/{result['dialect']}-p{result['processes']}-{result['label']}-{version_prefix}.stdout.json").read_text())
    expected = {f['path'] for f in manifest['files'] if f['path'].split('/')[1] == result['dialect']}
    assert {r['filepath'].replace('\\', '/') for r in records} == expected

rows = []
quality = {}
for dialect in ['ansi', 'snowflake', 'tsql']:
    for processes in [1, 4]:
        by_version = {}
        for version in ['4.4.0', '4.5.0']:
            observations = [r for r in results if (r['dialect'], r['processes'], r['version']) == (dialect, processes, version)]
            assert len(observations) == 5
            by_version[version] = observations
            assert len({r['violations'] for r in observations}) == 1
        a, b = [statistics.median(r['seconds'] for r in by_version[v]) for v in ['4.4.0', '4.5.0']]
        rows.append({'dialect': dialect, 'processes': processes, 'before': a, 'after': b,
                     'reduction': 100*(1-b/a), 'before_range': (min(r['seconds'] for r in by_version['4.4.0']), max(r['seconds'] for r in by_version['4.4.0'])),
                     'after_range': (min(r['seconds'] for r in by_version['4.5.0']), max(r['seconds'] for r in by_version['4.5.0']))})
    data = {}
    for version in ['4.4', '4.5']:
        data[version] = json.loads((ROOT / f'raw/{dialect}-p1-run1-{version}.stdout.json').read_text())
    signature = lambda entries: Counter((r['filepath'], v['code'], v.get('start_line_no'), v.get('start_line_pos')) for r in entries for v in r['violations'])
    quality[dialect] = {'same_codes_and_source_positions': signature(data['4.4']) == signature(data['4.5']),
                        'before_violation_counts': dict(Counter(v['code'] for r in data['4.4'] for v in r['violations'])),
                        'after_violation_counts': dict(Counter(v['code'] for r in data['4.5'] for v in r['violations']))}
(ROOT / 'quality.json').write_text(json.dumps(quality, indent=2))

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
fig, axes = plt.subplots(1, 2, figsize=(11, 5.5), sharex=True)
fig.patch.set_facecolor('#f7f8f8')
for ax, processes in zip(axes, [1, 4]):
    ax.set_facecolor('#f7f8f8')
    subset = [r for r in rows if r['processes'] == processes]
    for index, row in enumerate(subset):
        ax.barh(index-.17, row['before'], height=.29, color='#89959f', label='4.4.0' if index==0 else None)
        ax.barh(index+.17, row['after'], height=.29, color='#a35a00', label='4.5.0' if index==0 else None)
        ax.text(max(row['before'], row['after'])+.09, index, f"{row['reduction']:.0f}% less time", va='center', fontsize=10)
    ax.set_yticks(range(3), ['ANSI', 'Snowflake', 'T-SQL'])
    ax.invert_yaxis()
    ax.set_xlabel('Elapsed seconds (lower is better)')
    ax.set_title('One process' if processes==1 else 'Four worker processes', loc='left', pad=18, fontsize=13)
    ax.xaxis.grid(True, color='#d7dde0', alpha=.7)
    ax.set_axisbelow(True)
    ax.set_xlim(0, max(max(r['before'], r['after']) for r in rows)*1.48)
fig.legend(*axes[0].get_legend_handles_labels(), loc='upper right', bbox_to_anchor=(.96, .91), ncol=2, frameon=False)
fig.suptitle('SQLFluff 4.5.0: less time spent linting', x=.07, ha='left', fontsize=19, fontweight='bold')
fig.text(.07,.89,'Median of five CLI runs per release; 24 public fixtures per dialect.',fontsize=11,color='#5e6a72')
fig.text(.07,.035,'Python 3.13.15 · Python parser · raw templater · default rules · Windows 11 / Intel i5-12400F\nWarm filesystem cache. Small fixture samples; these results do not predict real-project performance.',fontsize=9,color='#5e6a72')
fig.subplots_adjust(left=.11,right=.96,top=.79,bottom=.19,wspace=.40)
fig.savefig(ROOT/'performance.png',dpi=180,facecolor=fig.get_facecolor())
fig.savefig(ROOT/'performance.svg',facecolor=fig.get_facecolor())

table = ''.join(f"<tr><td>{r['dialect'].upper()}</td><td>{r['processes']}</td><td>{r['before']:.3f}</td><td>{r['after']:.3f}</td><td>{r['reduction']:.1f}%</td><td>{r['before_range'][0]:.3f}–{r['before_range'][1]:.3f}</td><td>{r['after_range'][0]:.3f}–{r['after_range'][1]:.3f}</td></tr>" for r in rows)
body = f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SQLFluff 4.4.0 vs 4.5.0 — benchmark evidence</title>
<style>body{{font:16px/1.65 system-ui;margin:40px auto;max-width:1100px;padding:0 20px;color:#1d252b;background:#f7f8f8}}h1,h2{{line-height:1.2}}img{{max-width:100%}}table{{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}}td,th{{padding:10px;text-align:left;border-bottom:1px solid #d7dde0}}pre{{overflow:auto;background:#eef1f2;padding:20px}}.table{{overflow:auto}}a{{color:#844800}}</style>
<h1>SQLFluff 4.4.0 vs 4.5.0</h1><p>Release-to-release CLI lint comparison · 5 November 2026 · public fixtures</p>
<img src="performance.svg" alt="Median lint elapsed time for 4.4.0 and 4.5.0 across three dialect samples, with one and four processes">
<h2>Measurements</h2><p>Seconds, including CLI startup, linting and JSON output. Each cell has five measured runs; ranges retain every observation.</p>
<div class="table"><table><tr><th>Dialect</th><th>Processes</th><th>4.4.0 median</th><th>4.5.0 median</th><th>Less time</th><th>4.4.0 range</th><th>4.5.0 range</th></tr>{table}</table></div>
<h2>Method</h2><ul><li>Identical Python 3.13.15 environments and dependency versions except SQLFluff; Python parser and raw templater; all default rules.</li>
<li>72 nonempty public fixtures from the 4.4.0 tag: 24 each for ANSI, Snowflake and T-SQL. Select files up to 20,000 bytes, sorted by (size, path), at evenly spaced size ranks. Selection was fixed before measuring performance. The manifest records source paths and SHA-256 checksums.</li>
<li>One warm-up for each release and scenario, followed by five pairs. Release order alternates within each scenario. Each observation is a fresh CLI process. Files are read only; this measures lint, not fix.</li>
<li>One-process and four-worker runs are separate comparisons. Four workers on small inputs incur overhead and can be slower than one process.</li>
<li>Explicit configuration, ignore local configuration, fixed PYTHONHASHSEED=0, no Rust package or external templater plugins. Parse, lex and template error counts were checked on every run. All expected files were processed.</li>
<li>Intel Core i5-12400F, 6 physical / 12 logical processors; Windows 11. Other desktop applications were running. There was no dedicated idle host or cache flushing. Medians and full ranges are reported; no timing outliers were removed.</li></ul>
<h2>Interpretation and limits</h2><p>This is a reproducible fixture sample, not a representative customer project, and not a universal speedup claim. Size-stratified grammar fixtures include both tiny and large statements. Results include all release changes, not only performance PRs. Different diagnostic wording and legitimate rule fixes may change findings; counts and source-position comparisons are recorded in <a href="quality.json">quality.json</a>. Timing instrumentation and JSON output are enabled equally in both versions.</p>
<p>The small ANSI four-worker difference is within the observed run-to-run variability; repeat on a quiet machine before treating it as a robust improvement. The real-project comparison is deferred. Rust, dbt/Jinja rendering, autofix throughput, cold-cache behaviour and CI/Linux performance have not been measured.</p>
<h2>Reproduce</h2><p>Use Python 3.13.15 on Windows. Unzip the evidence bundle, then run from its directory. Dependencies are pinned in the two requirements files.</p>
<pre>uv venv --python 3.13.15 env-4.4.0
uv venv --python 3.13.15 env-4.5.0
uv pip install --python env-4.4.0/Scripts/python.exe -r requirements-4.4.0.txt
uv pip install --python env-4.5.0/Scripts/python.exe -r requirements-4.5.0.txt
python benchmark.py</pre>
<p>The included corpus and manifest suffice for a rerun. To regenerate the corpus, remove the manifest and set SQLFLUFF_REPO to a local SQLFluff checkout containing tag 4.4.0. The runner uses the Windows virtual-environment layout.</p>
<p><a href="summary.csv">Summary CSV</a> · <a href="results.json">All measured observations</a> · <a href="manifest.json">Corpus manifest</a> · <a href="environment.json">Environment</a> · <a href="performance.png">PNG chart</a> · <a href="performance.svg">SVG chart</a></p>
</html>'''
(ROOT/'report.html').write_text(body,encoding='utf-8')
include = ['benchmark.py','analyze.py','benchmark.sqlfluff','manifest.json','environment.json','requirements-4.4.0.txt','requirements-4.5.0.txt','summary.csv','results.json','quality.json','report.html','performance.png','performance.svg','FIXTURES-LICENSE.md']
with zipfile.ZipFile(ROOT/'benchmark-evidence.zip','w',zipfile.ZIP_DEFLATED) as bundle:
    for name in include:
        bundle.write(ROOT/name,name)
    for folder in ['raw','corpus']:
        for file in (ROOT/folder).rglob('*'):
            if file.is_file():
                bundle.write(file,file.relative_to(ROOT))
print(json.dumps({'summary':rows,'quality':quality},indent=2))
